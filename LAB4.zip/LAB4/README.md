Instructions:
1. For this lab you will debug the Tip Calculator app that is provided for you in the TipCalculator-Wk4 folder. This app only calculates the tip amount that a user has to pay for their meal. It does not calculate the total. In your Week 4 Lab/Readme.md file, list and identify all errors that you find. Specify which file had the errors, what the error was and state what you did to fix the error.
2. Use the Error List window to find and correct any syntax errors that display when you try to run the app. Be sure to write down the errors as you encounter them. Put comments in your code to help you keep track of the errors.
3. Use the Internal Server Error page and its stack trace to find and correct any unhandled exceptions that occur when you run the app.
4. Set a breakpoint in the model class and step through its code to find the error that leads to the app calculating an incorrect tip amount.
5. Use the Developer Tools (as shown below) to find and correct the CSS issue that prevents the label elements from displaying with the expected width.
6. Upload your zipped corrected files to your GitHub Week 4 folder. Note: The errors that you found in the lab, the filename(s) where each error was found, and the corrections made to fix each error must all be listed in your Week 4 Lab/Readme.md file in GitHub. 
7.Submit your Week 4 GitHub repo link to Blackboard.

Errors:
0. To begin, I changed the <TargetFramework>net6.0</TargetFramework> to net7.0 (TipCalculator.csproj) in order for this to run on vscode. I also had to change this in the program file of the launch.json ("program": "${workspaceFolder}/LAB4/TipCalculator-Wk4/TipCalculator/bin/Debug/net7.0/TipCalculator.dll")
I also had to rebuild the project so that it is compatible with .net7 and deleted the .net6 folder.
1. When attempting to run the app, there is a missing ";" in TipCalculator.cs on line 16.
2. HomeController.cs, line 14: "Viewbag" needs to be changed to "ViewBag".
3. HomeController.cs, line 16: added a returns statement to View();
4. Index.cshtml, line 16: fifteem changed to fifteen, after changing this, I was able to view the actual web page.
5. site.css, line 13: widht changed to width.
6.TipCalculate.cs, line 15, mealcost.value was dividing by percent, not multiplying.