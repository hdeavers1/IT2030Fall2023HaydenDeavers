namespace HaydenCollectableAndToy.Models{

public class ProductData {
    
    public static List<ProductModel> GetProducts() {

        List<ProductModel> products = new List<ProductModel> {

            new ProductModel {
                ProductId = 1,
                ProductName = "Red Power Ranger",
                ProductDescription = "Classic Action Figure of the Red Power Ranger",
                ProductImage = "RedPowerRanger.jpeg",
                ProductPrice = 11
            },
             new ProductModel {
                ProductId = 2,
                ProductName = "Green Power Ranger",
                ProductDescription = "Classic Action Figure of the Green Power Ranger",
                ProductImage = "GreenPowerRanger.jpeg",
                ProductPrice = 11
            },
             new ProductModel {
                ProductId = 3,
                ProductName = "White Power Ranger",
                ProductDescription = "Classic Action Figure of the White Power Ranger",
                ProductImage = "WhitePowerRanger.jpg",
                ProductPrice = 11
            },
            new ProductModel {
                ProductId = 4,
                ProductName = "Black Power Ranger",
                ProductDescription = "Classic Action Figure of the Black Power Ranger",
                ProductImage = "BlackPowerRanger.jpeg",
                ProductPrice = 10
            },
             new ProductModel {
                ProductId = 5,
                ProductName = "Blue Power Ranger",
                ProductDescription = "Classic Action Figure of the Blue Power Ranger",
                ProductImage = "BluePowerRanger.jpeg",
                ProductPrice = 10
            },
             new ProductModel {
                ProductId = 6,
                ProductName = "Pink Power Ranger",
                ProductDescription = "Classic Action Figure of the Pink Power Ranger",
                ProductImage = "PinkPowerRanger.jpeg",
                ProductPrice = 10
            },
             new ProductModel {
                ProductId = 7,
                ProductName = "Yellow Power Ranger",
                ProductDescription = "Classic Action Figure of the Yellow Power Ranger",
                ProductImage = "YellowPowerRanger.jpeg",
                ProductPrice = 10
            }

        };
        return products;
    }

    public static ProductModel GetProduct(int id) {

        List<ProductModel> products = ProductData.GetProducts();
        foreach (ProductModel product in products) {
            
            if(product.ProductId == id) {
                return product;
            }
        }
        return new ProductModel();
    }
}
}