using System.ComponentModel.DataAnnotations;

namespace DataAnnotations;
public class ContactModel {

    [Required (ErrorMessage = "Please enter a First name")][StringLength(30, ErrorMessage = "First name must be 30 characters or less.")][RegularExpression("^[a-zA-Z0-9]+$",
ErrorMessage = "Last name must not contain special characters.")]public string? FirstName { get; set;}

    [Required (ErrorMessage = "Please enter a Last name")][StringLength(30, ErrorMessage = "Last name must be 30 characters or less.")][RegularExpression("^[a-zA-Z0-9]+$",
ErrorMessage = "Last name must not contain special characters.")]public string? LastName { get; set;}

    [Required(ErrorMessage = "Please enter an Address")]public string? Address { get; set;}
   [Required (ErrorMessage = "Please enter a valid Phone Number")][StringLength(10, ErrorMessage = "Must be 10 numbers")][RegularExpression("^[0-9]+$",
ErrorMessage = "Must be only numbers")]public string? Phone { get; set;}
    [Required (ErrorMessage = "Please enter an Email")][EmailAddress(ErrorMessage = "Invalid Email Address")]public string? Email { get; set;}
    [Required (ErrorMessage = "Please enter a Message")]public string? Message { get; set;}
}
    