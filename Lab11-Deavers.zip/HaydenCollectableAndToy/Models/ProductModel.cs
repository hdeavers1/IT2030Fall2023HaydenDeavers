using System.ComponentModel.DataAnnotations;
namespace HaydenCollectableAndToy.Models;
public class ProductModel {
    public int ProductId { get; set; }
    [Required (ErrorMessage = "Please enter a Product Name")]public string ProductName { get; set; } = string.Empty;
    [Required (ErrorMessage = "Please enter a Product Description")]public string ProductDescription { get; set; } = string.Empty;
    [Required (ErrorMessage = "Please enter a Product Image")]public string ProductImage { get; set; } = string.Empty;
    [DataType(DataType.Currency)]public decimal ProductPrice { get; set; }

}

