﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using HaydenCollectableAndToy.Models;
using System.Reflection.Metadata.Ecma335;

namespace HaydenCollectableAndToy.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }
public IActionResult About()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }
    public IActionResult FAQ()
    {
        return View();
    }
     public IActionResult Events()
    {
        return View();
    }


    [HttpGet]
    public IActionResult Tools()
    {
        HttpContext.Session.SetString("FirstName", "Hayden");
        HttpContext.Session.SetString("LastName", "Deavers");
        HttpContext.Session.SetString("Course", "IT2030");
        HttpContext.Session.SetString("FavNum", "69");

        return View(new MySession());
    }   
    [HttpPost]
    public IActionResult Tools(MySession session) 
    {
        HttpContext.Session.SetString("FirstName", session.FirstName);
        HttpContext.Session.SetString("LastName", session.LastName);
        HttpContext.Session.SetString("Course", session.Course);
        HttpContext.Session.SetString("FavNum", session.FavNum);

        return RedirectToAction(nameof(Tools));

    }
    [HttpPost]
    public IActionResult ClearSession()
    {
        HttpContext.Session.Clear();
        return RedirectToAction(nameof(Tools));
    }

    [HttpGet]
public IActionResult DisplaySession()
{
    MySession session = new MySession
    {
        FirstName = HttpContext.Session.GetString("FirstName"),
        LastName = HttpContext.Session.GetString("LastName"),
        Course = HttpContext.Session.GetString("Course"),
        FavNum = HttpContext.Session.GetString("FavNum")
    };

    return View("Tools", session);
}

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
