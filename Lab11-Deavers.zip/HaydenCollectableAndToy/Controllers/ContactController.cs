using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using HaydenCollectableAndToy.Models;
using DataAnnotations;

namespace HaydenCollectableAndToy.Controllers;

public class ContactController : Controller {

    [HttpGet]
    public IActionResult Index() {

        ViewBag.FV = 0;
        return View();
    }

    [HttpPost]
    public IActionResult Index(ContactModel model){

        if (ModelState.IsValid) {

            return RedirectToAction("Index");
        }
    return View(model);
    }
}