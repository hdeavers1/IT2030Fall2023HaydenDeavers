using System.ComponentModel.DataAnnotations;

namespace DataAnnotations;
public class ContactModel {

    [Required (ErrorMessage = "Please enter a First name")]public string? FirstName { get; set;}
    [Required (ErrorMessage = "Please enter a Last name")]public string? LastName { get; set;}
    [Required(ErrorMessage = "Please enter an Address")]public string? Address { get; set;}
   [Required (ErrorMessage = "Please enter a valid Phone Number")]public string? Phone { get; set;}
    [Required (ErrorMessage = "Please enter an Email")]public string? Email { get; set;}
    [Required (ErrorMessage = "Please enter a Message")]public string? Message { get; set;}
}
    